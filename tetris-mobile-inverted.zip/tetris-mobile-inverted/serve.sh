#!/usr/bin/env bash
set -e
PORT="${1:-8080}"
echo "Serving on http://localhost:${PORT} (Ctrl+C to stop)"
python3 -m http.server "${PORT}"
