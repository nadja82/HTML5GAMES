# Tetris (HTML5, invertiert, mobil-optimiert)

## Quickstart
```bash
cd tetris-mobile-inverted
./serve.sh   # startet lokalen Webserver auf http://localhost:8080
```

Oder direkt `index.html` doppelklicken (Audio auf Mobilgeräten braucht Interaktion).

## Konfiguration
- **Seitenhintergrund:** `page-bg.png` (Body)
- **Board-Hintergrund:** `board-bg.png` (Canvas)
- **Sounds:** Dateien in `./sounds/` ablegen. Erwartete Namen (MP3):
  - Rotate1/2/3.mp3
  - MoveLeft1/2/3.mp3
  - MoveRight1/2/3.mp3
  - Hard1/2/3.mp3
  - Clear1/2/3.mp3
  - LevelUp1.mp3

Im Code (CONFIG) kannst du `soundExt` auf `wav`/`ogg` umstellen.

### URL-Overrides
- `?pageBg=media/bg.png`
- `?boardBg=media/board.png`
- `?levelMsg=GG%20zu%20Level%20{n}!`

## Steuerung
- Tasten: ←/→ bewegen, ↑ drehen, ↓ schneller, Leertaste Hard Drop, P Pause.
- Touch: On-Screen-Buttons mit Hold-Repeat.

## Features
- 7-Bag RNG, Level-Speed, Score/Lines, Highscore (localStorage)
- Effekte: Line-Clear-Flash, Impact-Flash, Hard-Drop-Trail, Level-Pulse, Feuerwerk, Toast-Nachricht
- PNG-Hintergründe für Seite & Board
- Soundeffekte pro Move/Clear/LevelUp (per Button 🔇/🔊 aktivierbar)
